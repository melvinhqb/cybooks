package org.example.javafc;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.example.javafc.models.Book;
import org.example.javafc.models.Loan;
import org.example.javafc.models.User;


import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.example.javafc.LibraryApp.bookApi;
import static org.example.javafc.LibraryApp.userDAO;


public class LibraryAppFX extends Application {

    private LibraryApp libraryApp = new LibraryApp();

    private BorderPane mainLayout;
    private GridPane userManagementGrid;
    private GridPane bookSearchGrid;
    private GridPane loanManagementGrid;
    private GridPane statisticsGrid;
    User sessionUser=null;

    @Override
    public void start(Stage primaryStage) {

        primaryStage.setTitle("Library Application");

        mainLayout = new BorderPane();
        mainLayout.setPadding(new Insets(10));

        // Main Menu
        displayMainMenu();

        Scene scene = new Scene(mainLayout, 400, 550);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void displayMainMenu() {
        mainLayout.getChildren().clear(); // Clear existing content
        mainLayout.setCenter(null);

        Text mainMenuText = new Text("Main Menu");
        mainLayout.setTop(mainMenuText);

        if(sessionUser!=null){
            Text userName = new Text(sessionUser.getFullName());
            mainLayout.setTop(userName);
        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        Button userManagementButton = new Button("User Management");
        userManagementButton.setOnAction(e -> displayUserManagementMenu());
        grid.add(userManagementButton, 0, 0);

        Button bookSearchButton = new Button("Book Search");
        bookSearchButton.setOnAction(e -> {
            VBox layout = new VBox();
            Label errorLabel = new Label();
            pickFilters(layout, errorLabel); // Pass the VBox and Label to searchBooks
            mainLayout.setCenter(layout); // Update the main layout with the new VBox containing the search results
        });
        grid.add(bookSearchButton, 0, 1);

        Button loanManagementButton = new Button("Loan Management");
        loanManagementButton.setOnAction(e -> displayLoanManagementMenu());
        grid.add(loanManagementButton, 0, 2);

        Button statisticsButton = new Button("Statistics");
        statisticsButton.setOnAction(e -> displayStatisticsMenu());
        grid.add(statisticsButton, 0, 3);

        if(sessionUser!=null){
            Button disconnect = new Button("Disconnect User");
            disconnect.setOnAction(e ->{sessionUser=null; displayMainMenu();});
            grid.add(disconnect, 0, 4);
        }else {
            Button connect = new Button("Connect User");
            connect.setOnAction(e ->connectUser());
            grid.add(connect, 0, 4);
        }


        mainLayout.setCenter(grid);
    }


    public void connectUser() {
        VBox layout = new VBox(10); // VBox to hold components with spacing of 10
        AtomicInteger userId = new AtomicInteger();

        // Create label and input field for user ID
        Label userIdLabel = new Label("Enter User ID:");
        TextField userIdField = new TextField();
        userIdField.setPromptText("User ID");

        // Create buttons
        Button connectButton = new Button("Connect");
        connectButton.setOnAction(event -> {
            try {
                userId.set(Integer.parseInt(userIdField.getText())); // Store input in userIdString
            } catch (NumberFormatException ex) {
                showError("Please enter a valid user ID.");
                return;
            }
            User usertemp = userDAO.find(userId.get());
            if (usertemp == null) {
                showError("User not found.");
            } else {
                sessionUser = usertemp;
                System.out.print(sessionUser.getFullName());
                displayMainMenu();
            }
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setOnAction(event -> displayMainMenu()); // Display main menu on cancel

        // Add components to layout
        layout.getChildren().addAll(userIdLabel, userIdField, connectButton, cancelButton);

        // Set the layout to be displayed in the main layout
        mainLayout.setCenter(layout);
    }


    public void displayUserManagementMenu() {
        userManagementGrid = new GridPane();
        userManagementGrid.setHgap(10);
        userManagementGrid.setVgap(10);
        userManagementGrid.setPadding(new Insets(20));

        Text userManagementText = new Text("User Management Menu");
        userManagementGrid.add(userManagementText, 0, 0);

        Button registerUserButton = new Button("Register New User");
        registerUserButton.setOnAction(e -> registerNewUser());
        userManagementGrid.add(registerUserButton, 0, 1);

        Button modifyUserButton = new Button("Modify User Details");
        modifyUserButton.setOnAction(e -> modifyUserDetails());
        userManagementGrid.add(modifyUserButton, 0, 2);

        Button searchUserButton = new Button("Search User");
        searchUserButton.setOnAction(e -> searchUser());
        userManagementGrid.add(searchUserButton, 0, 3);

        Button displayUserButton = new Button("Display User Details");
        displayUserButton.setOnAction(e -> displayUserMenu());
        userManagementGrid.add(displayUserButton, 0, 4);

        Button returnButton = new Button("Return to Main Menu");
        returnButton.setOnAction(e -> displayMainMenu());
        userManagementGrid.add(returnButton, 0, 5);

        mainLayout.setCenter(userManagementGrid);
    }

    private void registerNewUser() {
        Stage registerUserStage = new Stage();
        registerUserStage.setTitle("Register New User");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20, 20, 20, 20));
        grid.setVgap(10);
        grid.setHgap(10);

        Label firstNameLabel = new Label("First Name:");
        GridPane.setConstraints(firstNameLabel, 0, 0);
        TextField firstNameField = new TextField();
        GridPane.setConstraints(firstNameField, 1, 0);

        Label lastNameLabel = new Label("Last Name:");
        GridPane.setConstraints(lastNameLabel, 0, 1);
        TextField lastNameField = new TextField();
        GridPane.setConstraints(lastNameField, 1, 1);

        Label emailLabel = new Label("Email:");
        GridPane.setConstraints(emailLabel, 0, 2);
        TextField emailField = new TextField();
        GridPane.setConstraints(emailField, 1, 2);

        Button registerButton = new Button("Register");
        GridPane.setConstraints(registerButton, 1, 3);
        registerButton.setOnAction(e -> {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String email = emailField.getText();

            // Validate input
            if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
                // Show error message
                showError("Please fill in all fields.");
                return;
            }

            if (!isValidEmail(email)) {
                // Show error message for invalid email format
                showError("Please enter a valid email address.");
                return;
            }


            User newUser = new User(0, firstName, lastName, email);

            boolean success = userDAO.create(newUser);
            // Here you would call the method to register the user
            // For now, let's just print the user details
            System.out.println("New User Registered:");
            System.out.println("First Name: " + firstName);
            System.out.println("Last Name: " + lastName);
            System.out.println("Email: " + email);

            // Close the registration window
            registerUserStage.close();
        });

        grid.getChildren().addAll(firstNameLabel, firstNameField, lastNameLabel, lastNameField,
                emailLabel, emailField, registerButton);

        Scene scene = new Scene(grid, 300, 200);
        registerUserStage.setScene(scene);
        registerUserStage.show();
    }

    private boolean isValidEmail(String email) {
        // Regular expression for validating email format
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void modifyUserDetails() {
        Stage modifyUserStage = new Stage();
        modifyUserStage.setTitle("Modify User Details");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20, 20, 20, 20));
        grid.setVgap(10);
        grid.setHgap(10);

        Label userIdLabel = new Label("User ID:");
        GridPane.setConstraints(userIdLabel, 0, 0);
        TextField userIdField = new TextField();
        GridPane.setConstraints(userIdField, 1, 0);

        Label firstNameLabel = new Label("First Name:");
        GridPane.setConstraints(firstNameLabel, 0, 1);
        TextField firstNameField = new TextField();
        GridPane.setConstraints(firstNameField, 1, 1);

        Label lastNameLabel = new Label("Last Name:");
        GridPane.setConstraints(lastNameLabel, 0, 2);
        TextField lastNameField = new TextField();
        GridPane.setConstraints(lastNameField, 1, 2);

        Label emailLabel = new Label("Email:");
        GridPane.setConstraints(emailLabel, 0, 3);
        TextField emailField = new TextField();
        GridPane.setConstraints(emailField, 1, 3);

        Button searchButton = new Button("Search");
        GridPane.setConstraints(searchButton, 2, 0);
        searchButton.setOnAction(e -> {
            String userIdStr = userIdField.getText();

            // Validate input
            if (userIdStr.isEmpty()) {
                // Show error message
                showError("Please enter a user ID.");
                return;
            }

            int userId;
            try {
                userId = Integer.parseInt(userIdStr);
            } catch (NumberFormatException ex) {
                // Show error message for invalid user ID format
                showError("Please enter a valid user ID.");
                return;
            }

            // Here you would call the method to find the user
            // For now, let's just print user details
            User user = userDAO.find(userId);
            if (user != null) {
                // Populate fields with user details
                firstNameField.setText(user.getFirstName());
                lastNameField.setText(user.getLastName());
                emailField.setText(user.getEmail());
            } else {
                showError("User with ID: " + userId + " not found.");
            }
        });



        Button modifyButton = new Button("Modify");
        GridPane.setConstraints(modifyButton, 1, 4);
        modifyButton.setOnAction(e -> {
            // Retrieve user ID, first name, last name, and email
            String userIdStr = userIdField.getText();
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String email = emailField.getText();

            // Validate input
            if (userIdStr.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || email.isEmpty()) {
                // Show error message
                showError("Please fill in all fields.");
                return;
            }

            // Convert user ID to integer
            int userId;
            try {
                userId = Integer.parseInt(userIdStr);
            } catch (NumberFormatException ex) {
                // Show error message for invalid user ID format
                showError("Please enter a valid user ID.");
                return;
            }

            // Find user
            User user = userDAO.find(userId);
            if (user != null) {
                // Update user details
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setEmail(email);

                // Update user in database
                boolean success = userDAO.update(user);
                if (success) {
                    System.out.println("User details updated successfully.");
                } else {
                    showError("Failed to update user details.");
                }
            } else {
                showError("User with ID: " + userId + " not found.");
            }

            // Close the modification window
            modifyUserStage.close();
        });

        grid.getChildren().addAll(userIdLabel, userIdField, searchButton, firstNameLabel, firstNameField,
                lastNameLabel, lastNameField, emailLabel, emailField, modifyButton);

        Scene scene = new Scene(grid, 300, 250);
        modifyUserStage.setScene(scene);
        modifyUserStage.show();
    }

    private void displayUserMenu() {
        Stage userMenuStage = new Stage();
        userMenuStage.setTitle("User Menu");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label enterUserIdLabel = new Label("Enter user ID:");
        TextField userIdField = new TextField();
        Button enterButton = new Button("Enter");

        enterButton.setOnAction(e -> {
            String userIdStr = userIdField.getText();

            // Validate input
            if (userIdStr.isEmpty()) {
                showError("Please enter a user ID.");
                return;
            }

            int userId;
            try {
                userId = Integer.parseInt(userIdStr);
            } catch (NumberFormatException ex) {
                showError("Please enter a valid user ID.");
                return;
            }

            User user = userDAO.find(userId);
            if (user != null) {
                displayUserOptionsMenu(userMenuStage, user);
            } else {
                showError("User with ID: " + userId + " not found.");
            }
        });

        layout.getChildren().addAll(enterUserIdLabel, userIdField, enterButton);

        Scene scene = new Scene(layout);
        userMenuStage.setScene(scene);
        userMenuStage.show();
    }

    private void displayUserOptionsMenu(Stage parentStage, User user) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label userInfoLabel = new Label(user.toString());
        layout.getChildren().add(userInfoLabel);

        Button currentLoansButton = new Button("Display Current Loans");
        currentLoansButton.setOnAction(e -> displayUserCurrentLoans(user));

        Button overdueLoansButton = new Button("Display Overdue Loans");
        overdueLoansButton.setOnAction(e -> displayUserOverdueLoans(user));

        Button loanHistoryButton = new Button("Display Loan History");
        loanHistoryButton.setOnAction(e -> displayUserLoanHistory(user));

        Button returnButton = new Button("Return to Main Menu");
        returnButton.setOnAction(e -> parentStage.close());

        layout.getChildren().addAll(currentLoansButton, overdueLoansButton, loanHistoryButton, returnButton);

        Scene scene = new Scene(layout);
        parentStage.setScene(scene);
    }

    private void searchUser() {
        Stage searchUserStage = new Stage();
        searchUserStage.setTitle("Search User");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label searchLabel = new Label("Search Term:");
        TextField searchField = new TextField();
        Button searchButton = new Button("Search");

        TableView<User> resultsTable = new TableView<>();
        TableColumn<User, String> firstNameColumn = new TableColumn<>("First Name");
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        TableColumn<User, String> lastNameColumn = new TableColumn<>("Last Name");
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        TableColumn<User, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        resultsTable.getColumns().addAll(firstNameColumn, lastNameColumn, emailColumn);

        layout.getChildren().addAll(searchLabel, searchField, searchButton, resultsTable);

        searchButton.setOnAction(e -> {
            String searchTerm = searchField.getText();

            // Validate input
            if (searchTerm.isEmpty()) {
                // Show error message
                showError("Please enter a search term.");
                return;
            }

            // Call the method to search for users using the entered search term
            List<User> results = userDAO.search(searchTerm);
            if (!results.isEmpty()) {
                resultsTable.setItems(FXCollections.observableArrayList(results));
            } else {
                showError("No users found with search term: '" + searchTerm + "'");
            }
        });

        Scene scene = new Scene(layout);
        searchUserStage.setScene(scene);
        searchUserStage.show();
    }


    private void displayUserCurrentLoans(User user) {
        Stage currentLoansStage = new Stage();
        currentLoansStage.setTitle("Current Loans");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        Label titleLabel = new Label("Current loans for user: " + user.getFirstName() + " " + user.getLastName());
        layout.getChildren().add(titleLabel);

        List<Loan> currentLoans = user.getCurrentLoans();

        if (!currentLoans.isEmpty()) {
            for (Loan loan : currentLoans) {
                Label loanLabel = new Label(loan.toString());
                layout.getChildren().addAll(loanLabel, new Separator(Orientation.HORIZONTAL));
            }
        } else {
            Label noLoansLabel = new Label("No current loans found for user with ID: " + user.getId());
            layout.getChildren().add(noLoansLabel);
        }

        Button closeButton = new Button("Close");
        closeButton.setOnAction(e -> currentLoansStage.close());
        layout.getChildren().add(closeButton);

        Scene scene = new Scene(layout);
        currentLoansStage.setScene(scene);
        currentLoansStage.show();
    }

    private void displayUserOverdueLoans(User user) {
        Stage overdueLoansStage = new Stage();
        overdueLoansStage.setTitle("Overdue Loans");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        List<Loan> overdueLoans = user.getOverdueLoans();

        if (!overdueLoans.isEmpty()) {
            Label titleLabel = new Label("Overdue loans for user: " + user.getFirstName() + " " + user.getLastName());
            layout.getChildren().add(titleLabel);

            for (Loan loan : overdueLoans) {
                Label loanLabel = new Label(loan.toString());
                layout.getChildren().addAll(loanLabel, new Label()); // Add loan details and spacing
            }
        } else {
            Label noOverdueLoansLabel = new Label("No overdue loans found for user with ID: " + user.getId());
            layout.getChildren().add(noOverdueLoansLabel);
        }

        Scene scene = new Scene(layout);
        overdueLoansStage.setScene(scene);
        overdueLoansStage.show();
    }

    private void displayUserLoanHistory(User user) {
        Stage loanHistoryStage = new Stage();
        loanHistoryStage.setTitle("Loan History");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        List<Loan> loanHistory = user.getLoanHistory();

        if (!loanHistory.isEmpty()) {
            Label titleLabel = new Label("Loan history for user: " + user.getFirstName() + " " + user.getLastName());
            layout.getChildren().add(titleLabel);

            for (Loan loan : loanHistory) {
                Label loanLabel = new Label(loan.toString());
                layout.getChildren().addAll(loanLabel, new Label()); // Add loan details and spacing
            }
        } else {
            Label noLoanHistoryLabel = new Label("No loan history found for user with ID: " + user.getId());
            layout.getChildren().add(noLoanHistoryLabel);
        }

        Scene scene = new Scene(layout);
        loanHistoryStage.setScene(scene);
        loanHistoryStage.show();
    }



    private void pickFilters(VBox layout, Label errorLabel) {
        if(sessionUser==null){
            connectUser();
        }else{
            System.out.println(sessionUser.getFullName());
            System.out.println("what");
        }
        TextField titleField = new TextField();
        titleField.setPromptText("Titre");
        TextField authorField = new TextField();
        authorField.setPromptText("Auteur");
        TextField dateField = new TextField();
        dateField.setPromptText("Date (AAAA)");
        TextField genreField = new TextField();
        genreField.setPromptText("Genre");

        // ChoiceBox for selecting number of results per page
        ChoiceBox<Integer> resultsPerPageChoice = new ChoiceBox<>(FXCollections.observableArrayList(5, 10, 15, 20, 30, 50));
        resultsPerPageChoice.getSelectionModel().select(1); // Selects 10 by default

        Button searchButton = new Button("Rechercher");
        Button cancelButton = new Button("Annuler");

        searchButton.setOnAction(e -> {
            bookApi.setJump(resultsPerPageChoice.getValue()); // Set the jump value based on the selected number of results per page

            bookApi.clearFilter(); // Clear previous filters

            boolean validInput = false;

            if (!titleField.getText().isEmpty()) {
                bookApi.addFilter("title", titleField.getText());
                validInput = true;
            }
            if (!authorField.getText().isEmpty()) {
                bookApi.addFilter("author", authorField.getText());
                validInput = true;
            }
            if (!dateField.getText().isEmpty()) {
                bookApi.addFilter("date", dateField.getText());
                validInput = true;
            }
            if (!genreField.getText().isEmpty()) {
                bookApi.addFilter("genre", genreField.getText());
                validInput = true;
            }

            if (!validInput) {
                errorLabel.setText("Erreur : Veuillez entrer au moins un filtre.");
            } else {
                errorLabel.setText(""); // Clear any previous error messages
                searchBooks(layout, errorLabel); // Proceed with the search
            }
        });

        cancelButton.setOnAction(e -> {
            bookApi.clearFilter(); // Clear all filters
            displayMainMenu();
        });

        layout.getChildren().addAll(
                new Label("Choisissez les filtres :"),
                titleField, authorField, dateField, genreField,
                new HBox(10, new Label("Résultats par page:"), resultsPerPageChoice, searchButton, cancelButton),
                errorLabel
        );
    }


    public void searchBooks(VBox layout, Label errorLabel) {
        if(sessionUser==null){
            connectUser();
        }else{
            System.out.println(sessionUser.getFullName());
            System.out.println("what");
        }
        List<Book> results = bookApi.searchBooksByMap();

        if (!results.isEmpty()) {
            Label resultSummary = new Label("\nNombre de resultat : " + bookApi.getMax() +", resultat de " + bookApi.getIndex() +" à " + (bookApi.getIndex() + results.size() - 1));

            // Display results using JavaFX UI components
            ListView<Book> resultList = new ListView<>(); // Use ListView of Book objects instead of strings
            resultList.getItems().addAll(results);

            resultList.getSelectionModel().setSelectionMode(SelectionMode.SINGLE); // Allow selecting only one item at a time

            layout.getChildren().clear();
            layout.getChildren().addAll(resultList, resultSummary);

            // Navigation buttons
            HBox navigation = new HBox(10);
            Button nextPageButton = new Button("Page Suivante");
            Button prevPageButton = new Button("Page Précédente");
            Button cancelButton = new Button("Annuler");
            Button selectButton = new Button("Select"); // New button for selecting a book

            nextPageButton.setOnAction(e -> {
                if (bookApi.getIndex() + bookApi.getJump() <= bookApi.getMax()) {
                    bookApi.setIndex(bookApi.getIndex() + bookApi.getJump());
                    results.clear();
                    results.addAll(bookApi.searchBooksByMap());
                    resultList.getItems().setAll(results);
                }
            });

            prevPageButton.setOnAction(e -> {
                if (bookApi.getIndex() > 1) {
                    bookApi.setIndex(bookApi.getIndex() - bookApi.getJump());
                    results.clear();
                    results.addAll(bookApi.searchBooksByMap());
                    resultList.getItems().setAll(results);
                }
            });

            cancelButton.setOnAction(e -> {
                layout.getChildren().clear();
                pickFilters(layout, errorLabel);
            });

            // Handle book selection
            selectButton.setOnAction(e -> {
                Book selectedBook = resultList.getSelectionModel().getSelectedItem();
                if (selectedBook != null) {
                    System.out.print(selectedBook.getTitle()+
                    selectedBook.getAuthor()); // Display book details when "Select" button is clicked
                    Loan loan = new Loan(selectedBook, sessionUser);
                }
            });

            if (bookApi.getIndex() + bookApi.getJump() <= bookApi.getMax()) {
                navigation.getChildren().add(nextPageButton);
            }
            navigation.getChildren().addAll(prevPageButton, cancelButton, selectButton);

            layout.getChildren().add(navigation);
        } else {
            // Handle case where no results are found
            errorLabel.setText("Aucun résultats trouvés");
            bookApi.clearFilter();
        }
    }


    private void addBookToLoans(Book newValue) {
        System.out.print("succes");
    }


    public void displayLoanManagementMenu() {
        loanManagementGrid = new GridPane();
        loanManagementGrid.setHgap(10);
        loanManagementGrid.setVgap(10);
        loanManagementGrid.setPadding(new Insets(20));

        Text loanManagementText = new Text("Loan Management Menu");
        loanManagementGrid.add(loanManagementText, 0, 0);

        // Add components for loan management

        Button returnButton = new Button("Return to Main Menu");
        returnButton.setOnAction(e -> displayMainMenu());
        loanManagementGrid.add(returnButton, 0, 5);

        mainLayout.setCenter(loanManagementGrid);
    }

    public void displayStatisticsMenu() {
        // Implement displaying statistics menu here
    }
}