package org.example.javafc;

import org.example.javafc.dao.DAOFactory;
import org.example.javafc.dao.api.BookAPI;
import org.example.javafc.dao.implement.LoanDAO;
import org.example.javafc.dao.implement.UserDAO;
import org.example.javafc.models.Book;
import org.example.javafc.models.Loan;
import org.example.javafc.models.User;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.LocalDateTime;
import java.util.List;

public class LibraryApp {
    public static final UserDAO userDAO = DAOFactory.getUserDAO();
    private static final LoanDAO loanDAO = DAOFactory.getLoanDAO();
    static final BookAPI bookApi = new BookAPI();

    public void displayUserManagementMenu() {
        Stage stage = new Stage();
        stage.setTitle("User Management");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Text menuText = new Text("User Management Menu");
        grid.add(menuText, 0, 0, 2, 1);

        Button registerUserButton = new Button("Register New User");
        registerUserButton.setOnAction(e -> registerNewUser());
        grid.add(registerUserButton, 0, 1);

        Button modifyUserButton = new Button("Modify User Details");
        modifyUserButton.setOnAction(e -> modifyUserDetails());
        grid.add(modifyUserButton, 0, 2);

        Button searchUserButton = new Button("Search User");
        searchUserButton.setOnAction(e -> searchUser());
        grid.add(searchUserButton, 0, 3);

        Button displayUserButton = new Button("Display User Details");
        displayUserButton.setOnAction(e -> displayUserMenu());
        grid.add(displayUserButton, 0, 4);

        Button returnButton = new Button("Return to Main Menu");
        returnButton.setOnAction(e -> stage.close());
        grid.add(returnButton, 0, 5);

        Scene scene = new Scene(grid, 300, 250);
        stage.setScene(scene);
        stage.show();
    }

    private void registerNewUser() {
        Stage stage = new Stage();
        stage.setTitle("Register New User");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Text firstNameText = new Text("Firstname:");
        grid.add(firstNameText, 0, 0);
        TextField firstNameField = new TextField();
        grid.add(firstNameField, 1, 0);

        Text lastNameText = new Text("Lastname:");
        grid.add(lastNameText, 0, 1);
        TextField lastNameField = new TextField();
        grid.add(lastNameField, 1, 1);

        Text emailText = new Text("Email:");
        grid.add(emailText, 0, 2);
        TextField emailField = new TextField();
        grid.add(emailField, 1, 2);

        Button submitButton = new Button("Register");
        submitButton.setOnAction(e -> {
            String firstName = firstNameField.getText();
            String lastName = lastNameField.getText();
            String email = emailField.getText();

            User newUser = new User(0, firstName, lastName, email);
            boolean success = userDAO.create(newUser);
            if (success) {
                showAlert("Success", "User registered successfully.");
            } else {
                showAlert("Error", "Failed to register user.");
            }
            stage.close();
        });
        grid.add(submitButton, 1, 3);

        Scene scene = new Scene(grid, 300, 200);
        stage.setScene(scene);
        stage.show();
    }

    private void modifyUserDetails() {
        // Similar to registerNewUser, create a GUI for modifying user details.
    }

    private void searchUser() {
        // Create a GUI for searching user.
    }

    private void displayUserMenu() {
        // Create a GUI for displaying user details.
    }

    public void searchBooks() {
        Stage stage = new Stage();
        stage.setTitle("Search Books");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        Text titleText = new Text("Title:");
        grid.add(titleText, 0, 0);
        TextField titleField = new TextField();
        grid.add(titleField, 1, 0);

        Text authorText = new Text("Author:");
        grid.add(authorText, 0, 1);
        TextField authorField = new TextField();
        grid.add(authorField, 1, 1);

        Text dateText = new Text("Date:");
        grid.add(dateText, 0, 2);
        TextField dateField = new TextField();
        grid.add(dateField, 1, 2);

        Text genreText = new Text("Genre:");
        grid.add(genreText, 0, 3);
        TextField genreField = new TextField();
        grid.add(genreField, 1, 3);

        Button searchButton = new Button("Search");
        searchButton.setOnAction(e -> {
            String title = titleField.getText();
            String author = authorField.getText();
            String date = dateField.getText();
            String genre = genreField.getText();

            bookApi.clearFilter();
            if (!title.isEmpty()) bookApi.addFilter("title", title);
            if (!author.isEmpty()) bookApi.addFilter("author", author);
            if (!date.isEmpty()) bookApi.addFilter("date", date);
            if (!genre.isEmpty()) bookApi.addFilter("genre", genre);

            List<Book> results = bookApi.searchBooksByMap();
            // Display the results in a new window or console.
            if (!results.isEmpty()) {
                results.forEach(System.out::println); // Placeholder for displaying results
            } else {
                showAlert("No Results", "No books found with the specified filters.");
            }
        });
        grid.add(searchButton, 1, 4);

        Scene scene = new Scene(grid, 300, 250);
        stage.setScene(scene);
        stage.show();
    }

    public void displayLoanManagementMenu() {
        // Similar structure for Loan Management menu.
    }

    public void displayStatisticsMenu() {
        // Similar structure for Statistics menu.
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
