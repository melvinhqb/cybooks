module org.example.javafc {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.net.http;

    // Export your packages
    exports org.example.javafc;
    exports org.example.javafc.models;
}
